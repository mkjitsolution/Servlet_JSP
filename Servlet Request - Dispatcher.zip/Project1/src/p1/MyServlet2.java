package p1;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MyServlet2
 */
public class MyServlet2 extends HttpServlet {
	

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		List<String> jobList = new ArrayList<String>();
		
		String technology = (String)request.getAttribute("technology");
		System.out.println(" servlet 2 "+technology);
		out.print("<br/> Technology From Servlet 1 "+technology);
		
		if(technology.equalsIgnoreCase("java")) // DB
		{
			jobList.add("Project- 1");
			jobList.add("Project- 101");
			jobList.add("Project- 11");
			jobList.add("Project- 31");
			
		}
		if(technology.equalsIgnoreCase("node.js")) //DB
		{
			jobList.add("Project- 2");
			jobList.add("Project- 201");
			
		}
		
		request.setAttribute("jobList", jobList);
		
		request.getRequestDispatcher("MyServlet3").forward(request, response);
		
		
		
		
		///=========================================================
		
		ServletContext context = getServletContext();
		String serverLocation = context.getInitParameter("server-location");
		
		ServletConfig config = getServletConfig();
		String devName = config.getInitParameter("Servlet-Developer-Name");
		
		out.println("<b> From Servlet-Context </b> "+serverLocation);
		out.println("<br/><b> From Servlet-Config </b> "+devName);
	}

}
