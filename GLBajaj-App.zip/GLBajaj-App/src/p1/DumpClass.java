package p1;


class Animal{   // HttpServlet
	
	public void doEat()   // doGet()
	{
		
	}
	
}
   // GLBajajHomePage 
class Dog extends Animal{

	@Override
	public void doEat() {   // doGet()
		// code to add eating behavior of dog
	}
		
	
	
}

public class DumpClass {

}
