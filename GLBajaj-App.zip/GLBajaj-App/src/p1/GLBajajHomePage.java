package p1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class GLBajajHomePage extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		System.out.println(" --- Inside doGet of GLBajajHomePage ");
		
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		
		
		int x = Integer.parseInt(req.getParameter("number1"));
		int y = Integer.parseInt(req.getParameter("number2"));
		
		out.print("Sum of "+x+" & y "+y+" is "+(x+y));
		
		
		//resp.sendRedirect("NewFile.jsp");
	}
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		out.print("Hello get");
		
		
	}
	
	

}


