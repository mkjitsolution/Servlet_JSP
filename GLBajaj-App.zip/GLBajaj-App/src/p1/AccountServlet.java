package p1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Accounts;
import service.AccountsService;

/**
 * Servlet implementation class AccountServlet
 */
public class AccountServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		// reading data from form 
		String accountHolder = request.getParameter("accountHolder");
		int accountNumber  = Integer.parseInt(request.getParameter("accountNumber"));
		int balance = Integer.parseInt(request.getParameter("accountBalance"));

		// Business Operation
		Accounts accounts = new Accounts(accountNumber, accountHolder, balance);
		String policyName = new AccountsService().getPolicy((accounts));
		
		
		// UI 
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.print("Policy to Offer for "+accountHolder+"  is "+policyName);
		
	}

}
