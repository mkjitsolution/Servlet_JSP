package service;

import model.Accounts;

public class AccountsService {
	
	
	public String getPolicy(Accounts a) // method return policyName to offer
	{
		if(a.getBalance()>10001 && a.getBalance()<20000) return "Policy-B";
		else if(a.getBalance()>20001 ) return "Policy-C";
		else return " No Policy for Balance"+a.getBalance();
	}

}
